package com.stringprograms;

public class CheckStringWithDigitUppercaseLetter {
	
	public static void main(String[] args) {
		
		String s = "java8FeaTures";
		
		char[] charArray= s.toCharArray();
		
		for(int i = 0; i<charArray.length;i++) {
			if (Character.isDigit(charArray[i])) {
				System.out.println("digit in string "+s+"= "+charArray[i]);
			}
			
			if (Character.isUpperCase(charArray[i])) {
				System.out.println("uppercase letter in string "+s+"= "+charArray[i]);
			}
		}
	}

}
