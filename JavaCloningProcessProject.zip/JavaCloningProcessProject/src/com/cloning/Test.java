package com.cloning;

public class Test {

	public static void main(String[] args) {

		Vehicle v1 = new Vehicle(101, "Ather");

		System.out.println("Original copy--------------");

		System.out.println("v1= " + v1);

		System.out.println("v1.hashcode(): " + v1.hashCode());

		Vehicle v2 = null;

		try {
			v2 = (Vehicle) v1.clone();
		} catch (CloneNotSupportedException e) {
			System.out.println(e);
		}

		System.out.println("Cloned copy--------------");

		System.out.println("v2= " + v2);

		System.out.println("v2.hashcode(): " + v2.hashCode());

		System.out.println("--------------------------------");

		Vehicle v3 = v1;

		System.out.println("v3= " + v3);

		System.out.println("v3.hashcode(): " + v3.hashCode());

	}
}
