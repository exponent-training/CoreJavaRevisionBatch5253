package com.nestedclass;

import com.nestedclass.CPU.ArithmeticLogicUnit;

public class Application {

	public static void main(String[] args) {
		
		CPU c = new CPU();
		System.out.println();
		
		CPU.ArithmeticLogicUnit ca = c.new ArithmeticLogicUnit();
		
		CPU.ArithmeticLogicUnit ca1 = new CPU().new ArithmeticLogicUnit();
		
		ca.calculate();
		
		ca.displayInfo();
		
		System.out.println("-----------------------------------------------------");
		
		CPU.RAMMemory cr = new CPU().new RAMMemory();
		
		cr.displayRamData();
		System.out.println("-----------------------------------------------");
		
		cr.usageOfSameVariables();
		
		
		
		CPU c1 = new CPU();
		
		c1.getInstanceOfCache();
		
		
		
		
		
		
		
		
		
		
		
		
		
	//	ArithmeticLogicUnit a = new ArithmeticLogicUnit(); It won't apply to separately create inner class object 
		//We need to create it along with CPU.ArithmeticLogicUnit ca = c.new ArithmeticLogicUnit();
		//Because of this Tight coupling occurs that we don't want.
	}
}
