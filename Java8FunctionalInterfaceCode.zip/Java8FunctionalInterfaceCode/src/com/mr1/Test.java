package com.mr1;

public class Test {
	
	public static void main(String[] args) {
		
		/*
		 * System.out.println("lambda expression.."); Printable p = ()->
		 * System.out.println("Welcome to exponent.."); p.print();
		 */
		
		System.out.println("method ref...");
		Demo d = new Demo();
		Printable p1 = d::display;
		p1.print(780);
	}

}
