package com.patterns;

public class Pattern6 {
	
	public static void main(String[] args) {
		
		for(int i = 5; i>=1;i--) {
			for(int j = (2*5)-i; j>i;j--) {
				System.out.print(" ");
			}
			for(int k = 1;k<=i;k++) {
				System.out.print("* ");
			}
			System.out.println();
		}
	}

}
