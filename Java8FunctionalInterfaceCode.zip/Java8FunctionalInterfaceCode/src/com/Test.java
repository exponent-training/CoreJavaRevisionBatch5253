package com;

import java.util.function.Function;

public class Test {

	/*
	 * @Override public Integer apply(String str) {
	 * 
	 * int n = str.length(); return n; }
	 */

	public static void main(String[] args) {
		/*
		 * Function f = new Function<String, Integer>() {
		 * 
		 * @Override public Integer apply(String t) { int i = t.length(); return i; }
		 * 
		 * };
		 * 
		 * System.out.println(f.apply("html"));
		 */

		Function<String, Integer> f = (s) -> {
			return s.length();
		};
		
		System.out.println(f.apply("angular"));;

	}
}
