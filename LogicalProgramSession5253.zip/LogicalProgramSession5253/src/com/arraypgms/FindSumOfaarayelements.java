package com.arraypgms;

public class FindSumOfaarayelements {
	public static void main(String[] args) {
		int[] array = new int[] {10,2,3,4,50,6};
		
		int sum = 0;
		
		for(int i = 0;i<array.length;i++) {
			sum = sum + array[i];
		}
		
		System.out.println("sum = "+sum);
		
		int prod = 1;
		
		for(int i = 0;i<array.length;i++) {
			prod = prod * array[i];
		}
		
		System.out.println("prod = "+prod);
		
	}
}
