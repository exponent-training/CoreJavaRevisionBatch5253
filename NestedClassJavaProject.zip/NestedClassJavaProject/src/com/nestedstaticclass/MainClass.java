package com.nestedstaticclass;

public class MainClass {
	
	public static void main(String[] args) {
		
		Car.Engine ce = new Car.Engine();
		
		ce.displayInfo("Diesel type");
	}

}
