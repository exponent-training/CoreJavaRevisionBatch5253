package com.flatmap;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class Application {
	public static void main(String[] args) {

		List<Company> cList = Arrays.asList(
				new Company(101, "IT", Arrays.asList("guari", "priya", "raj", "aaditya", "jay")),
				new Company(102, "Finance", Arrays.asList("Alina", "Ram", "Girish", "Sonal")),
				new Company(103, "HR", Arrays.asList("Sam", "Aparna", "Rahul")),
				new Company(101, "Admin", Arrays.asList("Avinash", "Pratik", "Rashmi", "Pallavi")));

		cList.stream().map(emp -> emp.getDname()).forEach(System.out::println);
		System.out.println("--------------------------------");
		List<List<String>> eList = cList.stream().map(emp -> emp.getEmployeenames()).collect(Collectors.toList());

		System.out.println(eList);

		System.out.println("---------------------------------------------");

		List<String> employees = cList.stream().flatMap(emp -> emp.getEmployeenames().stream())
				.collect(Collectors.toList());
		System.out.println(employees);
		
		System.out.println("No of employees: "+employees.size());

		System.out.println("-----------------------");

		int num = 5246;

		String str = String.valueOf(num);

		String[] strArray = str.split("");
		
		long sum = Arrays.stream(strArray).collect(Collectors.summarizingInt(Integer::parseInt)).getSum();
		
		System.out.println("sum = "+sum);
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	}
}
