package com.arraypgms;

import java.util.Arrays;

public class LeftRotateArrayElements {

	public static void main(String[] args) {
		int[] array = { 1, 2, 3, 4, 5 }; // {5,1,2,3,4}

		int n = 1;

		System.out.println("Original Array : " + Arrays.toString(array));
		int temp = array[0];// {2,3,4,5,1}

		for (int i = 0; i < n; i++) {
			// temp = array[array.length-1-i];
			for (int j = 0; j < array.length - 1; j++) {
				array[j] = array[j + 1];
			}
			// array[i]=temp; // {4,5,1,2,3}

			array[array.length - 1] = temp;
		}

		System.out.println("Array after left rotation: " + Arrays.toString(array));
	}
}
