package com.stringprograms;

import java.util.Arrays;
import java.util.stream.Collectors;

public class ReverseEachword {
	
	public static void main(String[] args) {
		String str = "java is portable";
		
		String[] strArray = str.split(" ");
		
		String tempstr = "";
		
		for(int i =0; i<strArray.length;i++) {
			System.out.println(strArray[i]);
			
			StringBuilder sb = new StringBuilder(strArray[i]);
			tempstr = tempstr + sb.reverse()+" ";
			
		}
		System.out.println("------------------------------");
		System.out.println(tempstr);
		//System.out.println(tempstr.join("\\s", tempstr));
		
		System.out.println(Arrays.stream(strArray).map(s-> new StringBuilder(s).reverse()).collect(Collectors.joining(" ")));
		
	}

}
