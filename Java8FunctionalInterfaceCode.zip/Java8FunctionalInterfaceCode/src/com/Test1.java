package com;

import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.function.Supplier;

public class Test1 {

	public static void main(String[] args) {

		/*
		 * Predicate<Integer> p = (n) -> { return n > 0; };
		 * 
		 * 
		 * if (p.test(6)) { System.out.println("positive"); } else {
		 * System.out.println("negative"); }
		 */
		
		Consumer<String> c = (String str)->{
			System.out.println(str.toUpperCase());
		};
		
		c.accept("abcde");
		System.out.println("------------------------------------");
		Supplier<Double> s = ()->{
			return Math.random();
		};
		
		System.out.println(s.get());
	}

}
