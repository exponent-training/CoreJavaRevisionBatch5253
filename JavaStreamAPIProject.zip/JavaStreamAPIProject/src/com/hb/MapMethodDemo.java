package com.hb;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import com.api.Employee;

public class MapMethodDemo {

	public static void main(String[] args) {
		Arrays.asList(6, 1, 2, 3, 4).stream().map(n -> n + 5).forEach(System.out::println);

		List<Employee> empList = Arrays.asList(new Employee(101, "priya", "pune", 50000, 25),
				new Employee(102, "raj", "mumbai", 45000, 27), new Employee(103, "ram", "nashik", 67000, 30),
				new Employee(104, "rashmi", "thane", 27000, 25), new Employee(105, "jay", "nagar", 98000, 32),
				new Employee(106, "gauri", "nagar", 34000, 24));

		empList.stream().filter(emp -> emp.getSalary() >= 50000).map(emp -> emp.getEname())
				.forEach(System.out::println);

		empList.stream().filter(s -> s.getEname().startsWith("r")).map(s -> s.getEname().toUpperCase())
				.forEach(System.out::println);

		String str = "java8 new features";

		String[] strarray = str.split(" ");

		String strRev = Arrays.stream(strarray).map(str1 -> new StringBuilder(str1).reverse())
				.collect(Collectors.joining(" "));

		System.out.println("rev str= " + strRev);

		List<String> listOfNames = empList.stream().filter(s -> s.getEname().startsWith("r"))
				.map(s -> s.getEname().toUpperCase()).collect(Collectors.toList());

		System.out.println(listOfNames);

	}

}
