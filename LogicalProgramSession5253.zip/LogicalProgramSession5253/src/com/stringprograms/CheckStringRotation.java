package com.stringprograms;

public class CheckStringRotation {

	
	public static void main(String[] args) {
		String s1 = "abcdef";  //abcdefefabcd
		String s2 ="efabcd";  
		
		if (s1.length() == s2.length()) {
			s1=s1+s2;
			System.out.println(s1);
			if (s1.contains(s2)) {
				System.out.println("s2 is rotation of s1");
			} else {
				System.out.println("s2 is not rotation of s1");
			}
		} else {
			System.out.println("s2 is not rotation of s1");
		}
	}
}
