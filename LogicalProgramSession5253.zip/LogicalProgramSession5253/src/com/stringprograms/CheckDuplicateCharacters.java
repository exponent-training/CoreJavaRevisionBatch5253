package com.stringprograms;

public class CheckDuplicateCharacters {

	public static void main(String[] args) {

		int count;

		String s = "java programming";

		char[] charArray = s.toCharArray();

		for (int i = 0; i < charArray.length; i++) {  // i = 0 1 2  3
			count = 1;							//count = 1
			for (int j = i + 1; j < charArray.length; j++) { // j = 2 3
				if (charArray[i] == charArray[j] && charArray[i] != ' ') {
					count++;			//2
					charArray[j]='2';  //  charArray[3]='2'
				}
			}
			if (count>1) {
				System.out.println("Duplicate character: "+charArray[i]);
			}
		}
	}

}
