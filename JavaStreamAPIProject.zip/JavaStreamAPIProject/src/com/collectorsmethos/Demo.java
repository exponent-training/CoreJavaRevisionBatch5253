package com.collectorsmethos;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class Demo {

	public static void main(String[] args) {

		Stream<Integer> strInt = Stream.of(1, 2, 3, 4, 5);

		IntStream intStream = IntStream.of(1, 6, 9, 7, 8);

		List<Integer> list1 = strInt.collect(Collectors.toList());

		List<Integer> list2 = intStream.boxed().collect(Collectors.toList());

		// strInt.max

		/*
		 * int maxNo = intStream.max().getAsInt();
		 * 
		 * System.out.println("max no = "+maxNo);
		 */

		//System.out.println(intStream.sum());

		//intStream.filter(n -> n % 2 == 0).forEach(System.out::println);
		
		IntStream.range(1, 10).filter(n->n%2==0).forEach(System.out::println);
		System.out.println("-----------------------------------------");
		IntStream.rangeClosed(1, 10).filter(n->n%2==0).forEach(System.out::println);
		
		Arrays.asList(1,3,4,5,6).stream().filter(n->n%2==0).forEach(System.out::println);
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	}

}
