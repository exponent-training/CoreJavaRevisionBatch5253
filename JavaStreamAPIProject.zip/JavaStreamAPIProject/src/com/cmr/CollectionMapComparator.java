package com.cmr;

import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.stream.Collectors;

import com.api.Employee;



public class CollectionMapComparator {

	public static void main(String[] args) {
		Map<Employee, String> map = new HashMap<Employee, String>();
		
		map.put(new Employee(101, "priya", "pune", 50000, 28), "Developer");
		map.put(new Employee(102, "raj", "mumbai", 75000, 27), "Tester");
		map.put(new Employee(103, "ram", "nashik", 67000, 30), "Developer");
		map.put(new Employee(104, "rashmi", "thane", 27000, 25), "DBA");
		map.put(new Employee(105, "jay", "nagar", 98000, 32), "ProjectArchitect");
		map.put(new Employee(106, "gauri", "nagar", 34000, 25), "Tester");
		
		//System.out.println(map);
		
		Set<Entry<Employee,String>> entries = map.entrySet();
		
		//System.out.println(entries);
		entries.stream().map(entry -> entry.getKey()).sorted(Comparator.comparing(Employee::getSalary)).forEach(System.out::println);
		
		System.out.println("----------------------------------------------------");
		
		entries.stream().map(entry -> entry.getKey()).sorted(Comparator.comparing(Employee::getSalary)).forEach(k->System.out.println(k+"---"+map.get(k)));
		
		//entries.stream().map(entry -> entry.getKey()).sorted(Comparator.comparing(Employee::getSalary)).collect(Collectors.)
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
}
