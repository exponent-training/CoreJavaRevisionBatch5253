package com.arraypgms;

import java.util.Arrays;

public class MergeTwoArrays {
	public static void main(String[] args) {
		int[] array1 = { 11, 12, 13 };

		int[] array2 = { 15, 16, 17, 18 };

		int[] array3 = new int[array1.length + array2.length];

		int n1 = array1.length;

		int n2 = array2.length;

		int i = 0, j = 0, k = 0;

		for (int m = 0; m < array1.length; m++) {
			array3[m] = array1[m];
		}
		System.out.println(Arrays.toString(array3));

		for (int m = 0; m < array2.length; m++) {
			array3[array1.length+m] = array2[m];
			//k++;
		}

		/*
		 * while (i < n1) { array3[k] = array1[i]; i++; k++; }
		 * 
		 * while (j < n2) { array3[k] = array2[j]; j++; k++; }
		 */
		System.out.println(Arrays.toString(array3));
	}

}
