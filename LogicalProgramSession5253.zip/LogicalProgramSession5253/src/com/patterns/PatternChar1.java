package com.patterns;

import java.util.Scanner;

public class PatternChar1 {

	public static void main(String[] args) {

		/*
		 * System.out.println("enter value of n: "); Scanner sc = new
		 * Scanner(System.in); int n = sc.nextInt();
		 */
		// For rows
		for (char i = 'a'; i <= 'h'; i++) {

			// for columns
			for (char j = 'a'; j <= i; j++) {
				System.out.print(j+" ");
			}
			System.out.println();
		}
	}
}
