package com.patterns;

public class PatternChar2 {

	
	public static void main(String[] args) {

		/*
		 * System.out.println("enter value of n: "); Scanner sc = new
		 * Scanner(System.in); int n = sc.nextInt();
		 */
		// For rows
		for (char i = 'A'; i <= 'G'; i++) {

			// for columns
			for (char j = 'A'; j <= i; j++) {
				System.out.print(i+" ");
			}
			System.out.println();
		}
	}
}
