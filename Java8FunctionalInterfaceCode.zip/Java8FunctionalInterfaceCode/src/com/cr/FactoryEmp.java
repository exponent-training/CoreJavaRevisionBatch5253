package com.cr;

@FunctionalInterface
public interface FactoryEmp {
	
	public Employee createEmp();

}
