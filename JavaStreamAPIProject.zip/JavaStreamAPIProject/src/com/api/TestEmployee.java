package com.api;

import java.util.Arrays;
import java.util.List;

public class TestEmployee {
	
	public static void main(String[] args) {
		
		List<Employee> empList = Arrays.asList(new Employee(101, "priya", "pune", 50000, 25),new Employee(102, "raj", "mumbai", 45000, 27),
				new Employee(103, "ram", "nashik", 67000, 30),new Employee(104, "rashmi", "thane", 27000, 25)
				,new Employee(105, "jay", "nagar", 98000, 32));
		
		empList.stream().filter(emp->emp.getSalary()>=50000).forEach(System.out::println);
		System.out.println("--------------------");
		empList.stream().filter(emp-> emp.getAge()==25).forEach(System.out::println);
		
		
	}

}
