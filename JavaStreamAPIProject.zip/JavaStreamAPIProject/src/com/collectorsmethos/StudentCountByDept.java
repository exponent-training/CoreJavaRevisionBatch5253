package com.collectorsmethos;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class StudentCountByDept {
	
	public static void main(String[] args) {
		
		List<Student> studentList = Arrays.asList(new Student(11, "ganesh", "IT", 78.09f),new Student(12, "yash", "CSE", 90.0f),
				new Student(13, "rohan", "IT", 35.56f),new Student(14, "sunil", "E&TC", 76.50f),new Student(15, "aniket", "CSE", 95.09f));
		
		
		Map<String, Long> map = studentList.stream().collect(Collectors.groupingBy(Student::getDept, Collectors.counting()));
		
		System.out.println("map= "+map);
				
	}

}
