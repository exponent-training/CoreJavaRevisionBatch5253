package com.mr;

public class TotalClass {
	
	public static void sum() {
		int a= 10;
		int b=40;
		System.out.println("a+b= "+(a+b));
	}

}
