package com.nestedlocalclass;

public class A {
	
	public void m1() {
		
		
		System.out.println("m1--of A class---");
		class B{
			public void m2() {
				System.out.println("m2--of B inner class---");
			}
		}
		
		B b = new B();
		b.m2();
	}
	
	public static void main(String[] args) {
		A a = new A();
		
		a.m1();
	}

}
