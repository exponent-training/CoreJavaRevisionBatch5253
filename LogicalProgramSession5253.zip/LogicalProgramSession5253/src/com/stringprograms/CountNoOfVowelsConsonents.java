package com.stringprograms;

public class CountNoOfVowelsConsonents {

	public static void main(String[] args) {
		String str = "java programming"; //
		int countVowel = 0;
		
		int countConsonant = 0;

		String strLower = str.toLowerCase();

		for (int i = 0; i < strLower.length(); i++) {
			if (strLower.charAt(i)!=' ') {
				if (strLower.charAt(i) == 'a' || strLower.charAt(i) == 'e' || strLower.charAt(i) == 'i'
						|| strLower.charAt(i) == 'o' || strLower.charAt(i) == 'u') {
					countVowel++;
				}else {
					countConsonant++;
				}
			}
		}
		System.out.println("countVowel: "+countVowel);
		System.out.println("countConsonant: "+countConsonant);
	}

}
