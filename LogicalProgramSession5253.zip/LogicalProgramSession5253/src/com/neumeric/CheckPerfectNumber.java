package com.neumeric;

import java.util.Scanner;

public class CheckPerfectNumber {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter value of n: ");
		int n = sc.nextInt();

		//int n = 5;

		int sum = 0;
		
		for(int i = 1; i< n ;i++) {
			if (n%i == 0) {
				sum = sum + i;
			}
		}
		
		String str = (sum == n) ? n+" is Perfect number.":n+" is not a Perfect number.";
		
		System.out.println(str);

	}

}
