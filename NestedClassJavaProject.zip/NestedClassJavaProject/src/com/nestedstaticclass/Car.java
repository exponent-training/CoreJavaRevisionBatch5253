package com.nestedstaticclass;

public class Car {

	String name = "Kia";
	
	static class Engine{
		String enginetype;
		
		public void displayInfo(String enginetype) {
			this.enginetype = enginetype;
			
			Car c = new Car();
			System.out.println("Car "+c.name+" is of "+enginetype+" type..");
		}
	}
}
