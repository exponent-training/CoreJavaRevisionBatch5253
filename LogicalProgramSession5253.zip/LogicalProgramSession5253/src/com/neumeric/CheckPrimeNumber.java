package com.neumeric;

public class CheckPrimeNumber {
	
	public static void main(String[] args) {
		
		int num = 78;
		
		boolean flag = true;
		
		for(int i=2;i<=(num-1);i++) {
			if(num%i == 0) {
				flag = false;
			}
		}
		
		if (flag) {
			System.out.println(num+" is prime number");
		} else {
			System.out.println(num+" is not prime number");
		}
	}

}
