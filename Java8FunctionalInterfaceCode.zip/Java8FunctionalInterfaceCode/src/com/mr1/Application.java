package com.mr1;

import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;

public class Application {

	public static void main(String[] args) {

		String str = "html";

		Consumer<String> c = (String s) -> System.out.println(s.length());
		System.out.println("lambda expr------------");
		c.accept(str);

		System.out.println("Method ref-----------");

		Function<String, Integer> f = String::length;
		System.out.println(f.apply(str));

		List<String> strList = Arrays.asList("abc", "xyz", "pqr");
		System.out.println("lambda expr------------");
		Function<String, String> fStr = (s) -> {
			return s.toUpperCase();
		};
		
		for (String s : strList) {
			System.out.println(fStr.apply(s));
		}

		System.out.println("Method ref-----------");
		
		Function<String, String> fMR= String::toUpperCase;
		
		for (String s : strList) {
			System.out.println(fMR.apply(s));
		}
		
		
		
	}

}
