package com.mr1;


@FunctionalInterface
public interface Printable {

	public void print(int a);
}
