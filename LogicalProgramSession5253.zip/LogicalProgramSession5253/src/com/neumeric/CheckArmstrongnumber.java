package com.neumeric;

import java.util.Scanner;

public class CheckArmstrongnumber {

	public static void main(String[] args) {

		
		System.out.println("enter a number= ");
		Scanner sc = new Scanner(System.in);
		int num = sc.nextInt();
		//int num = 153;

		int countOfDigits = 0;

		int sum = 0, rem = 0;

		int armstrongNum = num;

		while (armstrongNum > 0) {
			armstrongNum = armstrongNum / 10;
			countOfDigits++;
		}

		System.out.println("Number of digits= " + countOfDigits);
		System.out.println("armstrongNum: " + armstrongNum);

		armstrongNum = num;

		while (armstrongNum > 0) {
			rem = armstrongNum % 10;
			sum = sum + (int) Math.pow(rem, countOfDigits);
			armstrongNum = armstrongNum / 10;
		}

		System.out.println("sum = " + sum);

		if (sum == num) {
			System.out.println(num + " is Armstrong number..");
		} else {
			System.out.println(num + " is not Armstrong number..");
		}

	}
}
