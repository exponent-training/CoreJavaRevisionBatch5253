package com.arraypgms;

import java.util.Arrays;

public class RightRotateArrayElements {

	public static void main(String[] args) {

		int[] array = { 1, 2, 3, 4, 5 }; // {5,1,2,3,4}

		int n = 2;

		System.out.println("Original Array : " + Arrays.toString(array));
		int temp;

		for (int i = 0; i < n; i++) {  // i = 1

			temp = array[array.length - 1]; // 5   {5,1,2,3,4}   4
			for (int j = array.length - 1; j > 0; j--) {
				array[j] = array[j - 1];   //  4=3 3=2 2=1 1=5              {4,5,1,2,3}
			}
			array[0] = temp;  //{5,1,2,3,4}
		}

		System.out.println("Array after right rotation: " + Arrays.toString(array));//[4, 5, 1, 2, 3]
	}

}
