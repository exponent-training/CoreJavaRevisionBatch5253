package com.mr;

@FunctionalInterface
public interface Printable {

	public void print();
}
