package com.neumeric;

import java.util.Scanner;

public class CheckDeckNoByString {
	
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter value of n: ");
		int n = sc.nextInt();

		String strNum = String.valueOf(n);
		
		if (strNum.contains("0")) {
			System.out.println( n + " is Duck number.");
		} else {
			System.out.println( n + " is not a Duck number.");
		}
	}

}
