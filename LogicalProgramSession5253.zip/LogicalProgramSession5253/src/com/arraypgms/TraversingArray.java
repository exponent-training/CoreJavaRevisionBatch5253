package com.arraypgms;

import java.util.Arrays;

public class TraversingArray {

	
	public static void main(String[] args) {
		int array[] = {11,23,59,67,20};
		
		for(int i = 0; i< array.length;i++) {
			System.out.println(array[i]);
		}
		
		System.out.println(Arrays.toString(array));
		
		System.out.println("printing array in reverse order:");
		for(int i = array.length-1;i>=0;i--) {
			System.out.println(array[i]);
		}
	}
}
