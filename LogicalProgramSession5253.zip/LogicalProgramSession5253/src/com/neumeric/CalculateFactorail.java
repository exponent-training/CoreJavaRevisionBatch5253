package com.neumeric;

public class CalculateFactorail {
	
	public static void main(String[] args) {
		
		int num = 9;
		
		int product =1;
		
		for(int i = num ; i>=1;i--) {
			product = product * i;
		}
		
		System.out.println("Factorial for "+num+" = "+product);
	}

}
