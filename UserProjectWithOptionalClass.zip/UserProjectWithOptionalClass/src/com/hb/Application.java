package com.hb;

import java.util.Optional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

public class Application {
	
	public static void main(String[] args) {
		
		SessionFactory sf = HibernateUtil.getSessionFactory();
		
		Session s = sf.openSession();
		
		
		/*
		 * User user1 = new User(); user1.setUsername("rahul");
		 * user1.setPassword("rahul898"); user1.setMobileno(8989787867l);
		 * 
		 * s.save(user1);
		 */
		
		 User user = s.get(User.class, 6);
		 Optional userObj = Optional.ofNullable(user);
		 
		 System.out.println(userObj.orElse("User doesn't exist!!"));
		System.out.println("success..");
		
	}

}
