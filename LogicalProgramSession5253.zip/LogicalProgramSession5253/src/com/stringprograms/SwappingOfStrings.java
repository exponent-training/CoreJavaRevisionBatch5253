package com.stringprograms;

public class SwappingOfStrings {

	public static void main(String[] args) {
		 
		String s1 = "html";
		String s2 = "css";
		
		System.out.println("before swapping : s1:"+s1+" & s2:"+s2);
		
		String temp = "";
		
		temp=s1;
		s1=s2;
		s2=temp;
		
		System.out.println("after swapping : s1:"+s1+" & s2:"+s2);
		
		int a = 15, b =10;
		
		System.out.println("before swapping : a:"+a+" & b:"+b);
		a=a+b;
		b=a-b;
		a=a-b;
		
		System.out.println("after swapping : a:"+a+" & b:"+b);
		
		System.out.println("-----------------------------------------------");
		
		String s3 = "cpp";
		String s4 = "java";
		
		s3 = s3.concat(s4);
		
		System.out.println("after concatination : s3: "+s3);
		
		//cppjava
		
	//	s3= s3.substring(0, )
		s4 = s3.substring(0, s3.length()-s4.length());
		System.out.println("s4 = "+s4);
		s3= s3.substring(s4.length());
		
		System.out.println("s3 = "+s3);
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
}
