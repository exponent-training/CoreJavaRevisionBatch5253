package com.listpgm;

import java.util.Optional;
import java.util.function.Consumer;

public class DemoOptional {

	public static void main(String[] args) {
		/*
		 * Optional op1 = Optional.empty(); System.out.println(op1);
		 */
		
		/*
		 * String s = null;
		 * 
		 * Optional op2 = Optional.of(s); System.out.println(op2);
		 * System.out.println(op2.get());
		 */
		
		String s1 = null;
		Optional op3 = Optional.ofNullable(s1);
		
		System.out.println(op3);
		//System.out.println(op3.get());
		
		if (op3.isPresent()) {
			System.out.println("name is "+op3.get());
		} else {
			System.out.println("value is null..");
		}
		
		System.out.println("-----------------------");
		
		Consumer<String> c= (k)->System.out.println("name is "+k);
	
		op3.ifPresent(c);
	}
}
