package com.anonymousinnerclass;

public abstract class Car {

	public abstract void m1();
}
