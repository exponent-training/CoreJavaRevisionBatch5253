package com.date;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Month;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

public class DateTimeDemo {
	
	public static void main(String[] args) {
		
		LocalDate date1 = LocalDate.now();
		
		System.out.println(date1);
		LocalDate ed = date1.plusDays(2);
		LocalDate ed2 = date1.minusDays(4);
		System.out.println(ed2);
		LocalDate em = date1.plusMonths(1);
		System.out.println(em);
		
		
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
		String formattedDate = LocalDate.now().format(formatter);
		System.out.println(formattedDate);
		
		LocalDateTime lt = LocalDateTime.now();
		
		DateTimeFormatter formatter1 = DateTimeFormatter.ofPattern("yyyy-MM-dd HH-mm-ss");
		String formattedDatetime = LocalDateTime.now().format(formatter1);
		
		System.out.println(lt);
		System.out.println(formattedDatetime);
		
		LocalTime lt1 = LocalTime.now();
		
		System.out.println(lt1);
		
		
		ZonedDateTime zdt = ZonedDateTime.now();
		
		System.out.println(zdt);
		
		LocalDate userdefinedDate=LocalDate.parse("2024-09-12");
		System.out.println(userdefinedDate);
		
		LocalDate ld1 = LocalDate.of(2004, 1, 14);
		System.out.println(ld1);
		
		LocalDate ld2 = LocalDate.of(2005, Month.APRIL, 25);
		System.out.println(ld2);
		
		
		System.out.println(LocalDate.parse("2022-09-23").getDayOfWeek());;
		
		System.out.println(LocalDate.parse("2022-09-23").getMonth());;
		
		
		
		
		
		
		
		
		
		
		
	}

}
