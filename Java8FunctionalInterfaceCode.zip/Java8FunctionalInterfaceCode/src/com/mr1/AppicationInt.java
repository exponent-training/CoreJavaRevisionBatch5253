package com.mr1;

import java.util.Arrays;
import java.util.List;
import java.util.function.Function;

public class AppicationInt {

	public static void main(String[] args) {
		List<String> list = Arrays.asList("114", "67", "500", "543");

		Function<String, Integer> f = (s) -> {
			return Integer.parseInt(s);
		};
		
		System.out.println("LE");
		for (String s : list) {
			System.out.println(f.apply(s));
		//	Integer i = f.apply(s);
	
		}
		Function<String, Integer> fMr = Integer::parseInt;
		
		System.out.println("MR");
		for (String s : list) {
			System.out.println(fMr.apply(s));
		//	Integer i = f.apply(s);
	
		}
		
		
	}
}
