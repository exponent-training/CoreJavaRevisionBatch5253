package com.shallowcloning;

public class Address {
	
	long pincode;
	
	String city;

	public long getPincode() {
		return pincode;
	}

	public void setPincode(long pincode) {
		this.pincode = pincode;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	@Override
	public String toString() {
		return "Address [pincode=" + pincode + ", city=" + city + "]";
	}

	public Address(long pincode, String city) {
		super();
		this.pincode = pincode;
		this.city = city;
	}
	
	

}
