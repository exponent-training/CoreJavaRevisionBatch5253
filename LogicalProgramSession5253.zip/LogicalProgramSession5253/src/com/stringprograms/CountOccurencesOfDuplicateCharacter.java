package com.stringprograms;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class CountOccurencesOfDuplicateCharacter {

	public static void main(String[] args) {

		String str = "java platform indepedent";
		
		String rStr = str.replaceAll("\\s", "");

		char[] array = str.toCharArray();

		Map<Character, Integer> map = new HashMap<Character, Integer>();

		for (char ch : array) {
			if (ch != ' ') {

				if (map.containsKey(ch)) {
					map.put(ch, map.get(ch) + 1);
				} else {
					map.put(ch, 1);
				}
			}
		}

		System.out.println("occurences of characters:");

		System.out.println(map);
		
		System.out.println("-----------------------java8-------------------------------------");
		
		
		Map hmap = Arrays.stream(rStr.split("")).collect(Collectors.groupingBy(Function.identity(),Collectors.counting()));
		System.out.println(hmap);
		
System.out.println(Arrays.stream(str.split("")).filter(s->!s.equals(" ")).collect(Collectors.groupingBy(Function.identity(),Collectors.counting())));
	}

}
