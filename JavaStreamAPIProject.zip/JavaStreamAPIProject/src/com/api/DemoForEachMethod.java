package com.api;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;

public class DemoForEachMethod {
	
	public static void main(String[] args) {
		
		List<String> list = Arrays.asList("java","js","angular","cpp");
		
		Consumer<String> c = (s)->System.out.println(s);
		for (String str : list) {
			c.accept(str);
		}
		
		System.out.println("----------forEach method------");
		list.forEach(c);
		System.out.println("----------forEach method direct------");
		list.forEach((s)->System.out.println(s));
		System.out.println("----------forEach method using Method Ref------");
		
		list.forEach(System.out::println);
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
