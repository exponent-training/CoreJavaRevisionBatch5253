package com.arraypgms;

import java.util.Arrays;

public class CopyOneArrayIntoAnother {
	
	public static void main(String[] args) {
		
		int[] array = new int[] {10,2,3,4,50,6};
		
		int[] copyArray = new int[array.length];
		
		for(int i =0;i<array.length;i++) {
			copyArray[i]=array[i];
		}
		
		System.out.println("Original Array = "+Arrays.toString(array));
		System.out.println("------------------------------------------------");
		System.out.println("copy Array = "+Arrays.toString(copyArray));
		
		int[] newarr = Arrays.copyOf(array, array.length);
		
		System.out.println("copy Array = "+Arrays.toString(newarr));
	}

}
