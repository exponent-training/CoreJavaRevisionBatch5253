package com.patterns;

import java.util.Scanner;

public class RevPattern1 {

	public static void main(String[] args) {

		/*
		 * System.out.println("enter value of n: "); Scanner sc = new
		 * Scanner(System.in); int n = sc.nextInt();
		 */
		// For rows
		for (int i = 4; i >= 1; i--) {

			// for columns
			for (int j = 1; j <= i; j++) {
				System.out.print("* ");
			}
			System.out.println();
		}
		System.out.println("----------------------------------");
		
		for (char ch = 65;ch<=71; ch++) {

			// for columns
			for (char j = 65; j <= ch; j++) {
				System.out.print(j+" ");
			}
			System.out.println();
		}
		
	}

}
