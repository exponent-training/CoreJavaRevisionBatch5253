package com.neumeric;

import java.util.Scanner;

public class ReverseNumberByString {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter value of n: ");
		int n = sc.nextInt();

		String strNum = String.valueOf(n);
		
		StringBuilder sb = new StringBuilder(strNum);
		

		System.out.println("Revesre Number = "+sb.reverse());
	}
}