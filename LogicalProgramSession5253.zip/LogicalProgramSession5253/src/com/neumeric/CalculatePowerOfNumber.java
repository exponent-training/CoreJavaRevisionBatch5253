package com.neumeric;

public class CalculatePowerOfNumber {
	
	public static void main(String[] args) {
		
		int num = 5;
		
		int power = 2;
		
		int product = 1;
		
		for(int i =1; i<=power;i++) {   // 1<=3    2<=3  3<=3
			product = product * num; /// 1 *2 =2    2*2=4   4*2 = 8   
		}
		
		System.out.println(num + "to the power "+power+" = "+product);
		
		System.out.println(Math.pow(5, 2));;
	}

}
