package com.cmr;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

import com.api.Employee;

public class DemoComparator {
	
	public static void main(String[] args) {
		
		System.out.println("Asc-------------------");
		Arrays.asList(5,6,7,2,9,5,3,9).stream().sorted().distinct().forEach(System.out::println);
		
		System.out.println("Desc-------------------");
		Arrays.asList(5,6,7,2,9,5,3,9).stream().sorted(Comparator.reverseOrder()).forEach(System.out::println);
		
		List<Employee> empList = Arrays.asList(new Employee(101, "priya", "pune", 50000, 25),new Employee(102, "raj", "mumbai", 45000, 27),
				new Employee(103, "ram", "nashik", 67000, 30),new Employee(104, "rashmi", "thane", 27000, 25)
				,new Employee(105, "jay", "nagar", 98000, 32));
		
		empList.stream().sorted(Comparator.comparing(Employee::getAge)).forEach(System.out::println);
	}

}
