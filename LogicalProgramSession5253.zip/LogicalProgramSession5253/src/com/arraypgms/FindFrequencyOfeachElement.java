package com.arraypgms;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class FindFrequencyOfeachElement {

	public static void main(String[] args) {

		int[] array = { 1, 2, 5, 1, 6, 1, 2, 6, 2 };

		Map<Integer, Integer> hmap = new HashMap<Integer, Integer>();

		for (int i = 0; i < array.length; i++) { // 0 1 2 3 4 5 6 7 8
			if (hmap.containsKey(array[i])) {
				hmap.put(array[i], hmap.get(array[i]) + 1); // 1 2 1 3 2 2 6 2 2 3
			} else {
				hmap.put(array[i], 1); // entry 1 3-- 2 3-- 5 1-- 6 2
			}
		}
		
		
		
	Set<Entry<Integer, Integer>> entries	=  hmap.entrySet();
		
		for (Entry<Integer, Integer> entry : entries) {
			System.out.println(entry.getKey()+"----"+entry.getValue());
		}
		
		
		
		
		
		
	}

	
	
	
	
	
	
	
	
	
	
	
	
	
}
