package com.listpgm;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.function.Supplier;

public class Test1 {

	public static void main(String[] args)  {
		Student s1 = new Student(23, "ram", "ram@gmail.com");
		Student s2 = new Student(24, "priya", "priya@gmail.com");
		Student s3 = new Student(21, "guarav", "guarav@gmail.com");
		Student s4 = null;

		List<Student> sList = new ArrayList<Student>();

		Collections.addAll(sList, s1,s2,s3,s4);
		
		System.out.println(sList);

		/*
		 * for (Student student : sList) { if (student.getEmail() != null) {
		 * System.out.println(student.getEmail()); } else {
		 * System.out.println("email is null!!"); } }
		 */
		
		
		
		for (Student student : sList) {
			Optional obj = Optional.ofNullable(student);
			//System.out.println(obj.get());
			
			//System.out.println(obj.orElse("Student doesn't exist!!"));
			
			//Supplier s= ()->{return "student not exist!!";};
			//System.out.println(obj.orElseGet(()->{return "student not exist!!";}));
			
			try {
				System.out.println(obj.orElseThrow(()->new NullPointerException("student not exist!!")));
			} catch (Throwable e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			System.out.println();
		}
	}

}
