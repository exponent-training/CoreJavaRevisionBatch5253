package com.entity;

import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Employee {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int eid;

	private String ename;

	private String gender;

	private int age;

	private String deptname;

	private int yearOfJoining;

	private String address;

	private double salary;

	public int getEid() {
		return eid;
	}

	public void setEid(int eid) {
		this.eid = eid;
	}

	public String getEname() {
		return ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getDeptname() {
		return deptname;
	}

	public void setDeptname(String deptname) {
		this.deptname = deptname;
	}

	public int getYearOfJoining() {
		return yearOfJoining;
	}

	public void setYearOfJoining(int yearOfJoining) {
		this.yearOfJoining = yearOfJoining;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	@Override
	public String toString() {
		return "Employee [eid=" + eid + ", ename=" + ename + ", gender=" + gender + ", age=" + age + ", deptname="
				+ deptname + ", yearOfJoining=" + yearOfJoining + ", address=" + address + ", salary=" + salary + "]";
	}

}



/*
 * How many male & female employees are there in organization?
 * 
 * employeeList.stream().forEach(System.out::println);;
 * 
 * System.out.println(employeeList.stream().filter(e->e.getDeptname().equals(
 * "Admin")).collect(Collectors.minBy(Comparator.comparing(Employee::getAge))).
 * get());;
 * 
 * List<Employee> list
 * =employeeList.stream().sorted(Comparator.comparing(Employee::getAge)).
 * distinct().collect(Collectors.toList()); System.out.println(list);
 * 
 * Employee empOldest =
 * employeeList.stream().collect(Collectors.minBy(Comparator.comparing(Employee:
 * :getAge))).get();
 * 
 * System.out.println(empOldest);
 * 
 * Optional<String> opStr = Optional.ofNullable(null);
 */