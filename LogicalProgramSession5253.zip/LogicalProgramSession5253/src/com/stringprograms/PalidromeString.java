package com.stringprograms;

public class PalidromeString {
	
	public static void main(String[] args) {
		String str = "Mom";
		
		String revstr = "";

		for (int i = str.length() - 1; i >= 0; i--) {
			revstr = revstr + str.charAt(i);
		}
		
		if (str.equalsIgnoreCase(revstr)) {
			System.out.println(str+" is palidrome.");
		} else {
			System.out.println(str+" is not palidrome.");
		}
	}

}
