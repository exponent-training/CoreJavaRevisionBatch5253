package com.controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;

import com.entity.Employee;
import com.util.HibernateUtil;

public class Payload {

	public static void savePayloadForEmployees() {

		Employee e1 = new Employee();
		e1.setEname("Shruti");
		e1.setGender("Female");
		e1.setAddress("Rajgurunagar");
		e1.setAge(26);
		e1.setDeptname("Sales");
		e1.setSalary(25000);
		e1.setYearOfJoining(2023);

		Employee e2 = new Employee();
		e2.setEname("Kalyani");
		e2.setGender("Female");
		e2.setAddress("Pune");
		e2.setAge(27);
		e2.setDeptname("HR");
		e2.setSalary(75000.12);
		e2.setYearOfJoining(2021);

		Employee e3 = new Employee();
		e3.setEname("Akshay");
		e3.setGender("Male");
		e3.setAddress("Nashik");
		e3.setAge(29);
		e3.setDeptname("Admin");
		e3.setSalary(87000);
		e3.setYearOfJoining(2017);

		Employee e4 = new Employee();
		e4.setEname("Sayali");
		e4.setGender("Female");
		e4.setAddress("Mumbai");
		e4.setAge(26);
		e4.setDeptname("IT");
		e4.setSalary(50000);
		e4.setYearOfJoining(2020);

		Employee e5 = new Employee();
		e5.setEname("Piyush");
		e5.setGender("Male");
		e5.setAddress("Pune");
		e5.setAge(28);
		e5.setDeptname("Sales");
		e5.setSalary(81000);
		e5.setYearOfJoining(2019);

		SessionFactory sf = HibernateUtil.getSessionFactory();

		Session session = sf.openSession();

		List<Employee> list = new ArrayList<Employee>();

		Collections.addAll(list, e1, e2, e3, e4, e5);

		// java8
		list.stream().forEach(emp -> session.save(emp));

		System.out.println("Employees added successfully!!");
	}

	public static List<Employee> geAllDetailsOfEmployees() {

		SessionFactory sf = HibernateUtil.getSessionFactory();

		Session session = sf.openSession();
		
		Query<Employee> query = session.createQuery("from Employee");
		
		List<Employee> empList = query.getResultList();

		return empList;
	}
}
