package com.stringprograms;

import java.util.Arrays;

public class CountNoOfChars {
	
	public static void main(String[] args) {
		 String str = "java programming";  //
		 int count = 0;
		 
		 for(int i=0; i< str.length();i++) {
			 if(str.charAt(i) != ' ') {
			 count++;
			 }
		 }
		 
		 System.out.println("count= "+count);
		 
		 System.out.println("------------------java8------------------");
		 String strReplace = str.replaceAll("\\s", "");
		String[] strArray = strReplace.split("");
		 
		 long countOfChar = Arrays.stream(strArray).count();
		
		 System.out.println("countOfChar = "+countOfChar);
		 System.out.println("-----------------------------------------------");
		 
		 long count1 = Arrays.stream(str.split("")).filter(ch->!ch.equals(" ")).count();
		 System.out.println("count1= "+count1);
	}

}
