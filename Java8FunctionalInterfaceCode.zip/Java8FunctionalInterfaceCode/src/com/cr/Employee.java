package com.cr;

public class Employee {
	
	public Employee() {
		System.out.println("def constr of Employee..");
	}

}
