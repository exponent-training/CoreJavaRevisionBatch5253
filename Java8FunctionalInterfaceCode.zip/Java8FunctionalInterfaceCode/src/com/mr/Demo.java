package com.mr;

public class Demo {

	public void m2() {
		System.out.println("Hello world!!");
	}
}
