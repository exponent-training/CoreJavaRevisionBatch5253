package com.neumeric;

import java.util.Scanner;

public class FindReverseNumber {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter num: ");

		int num = sc.nextInt();

		System.out.println("Original number= " + num);

		int sum = 0, rem = 0;

		while (num > 0) {
			rem = num % 10;
			sum = sum * 10 + rem;
			num = num / 10;
		}

		System.out.println("Rev num= " + sum);

	}
}
