package com;

public class A {

	public static void main(String[] args) {
		
		Interface1 i1 =  (i,j)-> System.out.println("product=="+(i*j));
		
		i1.m1(5,7);
	}
	
	

}
