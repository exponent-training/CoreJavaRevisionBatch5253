package com.stringprograms;

import java.util.Arrays;

public class CheckStringisAnagram {

	public static void main(String[] args) {

		String s1 = "care";
		String s2 = "Race";

		String s1Lower = s1.toLowerCase();
		String s2Lower = s2.toLowerCase();

		char[] chArray1 = s1Lower.toCharArray();
		char[] chArray2 = s2Lower.toCharArray();

		System.out.println(Arrays.toString(chArray1));
		System.out.println(Arrays.toString(chArray2));

		if (s1Lower.length() == s2Lower.length()) {

			Arrays.sort(chArray1);
			Arrays.sort(chArray2);

			String str1 = Arrays.toString(chArray1);
			String str2 = Arrays.toString(chArray2);

			if (str1.equals(str2)) {
				System.out.println("strings are Anagram.");
			} else {
				System.out.println("strings are not Anagram.");
			}

		} else {
			System.out.println("lengths of given strings are not equal , so strings are not Anagram.");
		}

	}

}
