package com.arraypgms;

import java.util.Arrays;

public class FindingNthLargestElement {

	public static void findLargestElement(int[] array) {

		System.out.println("Largest element from an array: " + array[array.length - 1]);
	}

	public static void find2ndLargestElement(int[] array) {

		System.out.println("2nd Largest element from an array: " + array[array.length - 2]);
	}

	public static void main(String[] args) {

		int array[] = { 78, 13, 56, 3, 40 };

		System.out.println("Original array: " + Arrays.toString(array));

		Arrays.sort(array);

		System.out.println("Sorted array: " + Arrays.toString(array));

		System.out.println("-------------------------------");

		findLargestElement(array);
		
		System.out.println("-------------------------------");

		find2ndLargestElement(array);
	}

}
