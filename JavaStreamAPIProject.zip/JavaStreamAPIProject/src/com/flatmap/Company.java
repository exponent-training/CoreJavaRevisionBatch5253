package com.flatmap;

import java.util.List;

public class Company {
	
	int cid;
	
	String dname;
	
	List<String> employeenames;

	public int getCid() {
		return cid;
	}

	public void setCid(int cid) {
		this.cid = cid;
	}

	public String getDname() {
		return dname;
	}

	public void setDname(String dname) {
		this.dname = dname;
	}

	public List<String> getEmployeenames() {
		return employeenames;
	}

	public void setEmployeenames(List<String> employeenames) {
		this.employeenames = employeenames;
	}

	@Override
	public String toString() {
		return "Company [cid=" + cid + ", dname=" + dname + ", employeenames=" + employeenames + "]";
	}

	public Company(int cid, String dname, List<String> employeenames) {
		super();
		this.cid = cid;
		this.dname = dname;
		this.employeenames = employeenames;
	}
	
	

}
