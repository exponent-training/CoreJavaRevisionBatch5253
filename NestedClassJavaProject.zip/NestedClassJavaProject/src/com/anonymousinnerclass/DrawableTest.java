package com.anonymousinnerclass;

public class DrawableTest {
	
	public static void main(String[] args) {
		
		//can one functional interface extends another functional interface
		
		Drawable d = new Drawable() {
			
			@Override
			public void draw() {
				System.out.println("drawing circle...");
				
			}

			@Override
			public void get() {
				System.out.println("get circle...");
				
			}
		};
		
		d.draw();
		
		d.get();
		
		
		Car c = new Car() {
			
			@Override
			public void m1() {
			System.out.println("m1---Car");
				
			}
		};
		
		c.m1();
	}

}
