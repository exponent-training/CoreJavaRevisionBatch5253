package com.arraypgms;

import java.util.HashSet;
import java.util.Set;

public class FindDuplicateElementsFromarray {
	
	public static void main(String[] args) {
		
		int[] array = {1,2,5,1,6,1,2,6,2};
		
		Set<Integer> set = new HashSet<Integer>();
		
		for(int i = 0; i<array.length;i++) {
			for(int j = i+1; j<array.length;j++) {
				if (array[i]==array[j]) {  // 0 1 2 3 4
					//System.out.println(array[i]); 
					//break;//1 1 2
					set.add(array[i]);
				}
			}
		}
		System.out.println(set);
	}

}
