/**
 * 
 */
/**
 * 
 */
module GarbageCollectorExample {
}