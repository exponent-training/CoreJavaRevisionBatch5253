package com.date;

import java.time.LocalDate;
import java.time.LocalDateTime;

public class DateTimeDemo {
	
	public static void main(String[] args) {
		
		LocalDate date1 = LocalDate.now();
		
		System.out.println(date1);
		
		LocalDateTime lt = LocalDateTime.now();
		
		System.out.println(lt);
	}

}
