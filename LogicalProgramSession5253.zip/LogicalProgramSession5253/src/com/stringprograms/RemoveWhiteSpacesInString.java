package com.stringprograms;

public class RemoveWhiteSpacesInString {
	
	public static void main(String[] args) {
		
		String str = "java is portable";
		
		String strWithNospaces=str.replaceAll("\\s", "");
		System.out.println(strWithNospaces);
	}

}
