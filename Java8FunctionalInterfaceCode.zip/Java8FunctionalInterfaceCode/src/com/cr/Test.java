package com.cr;

public class Test {
	
	public static void main(String[] args) {
		FactoryEmp factory = Employee::new;
		
		factory.createEmp();
	}

}
