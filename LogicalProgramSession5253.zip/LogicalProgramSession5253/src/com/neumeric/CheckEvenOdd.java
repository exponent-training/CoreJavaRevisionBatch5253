package com.neumeric;

import java.util.Scanner;

public class CheckEvenOdd {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter num: ");
		int num = sc.nextInt();

		for (int i = 1; i <= num; i++) {
			if (i % 2 == 0) {
				System.out.println(i + " is even integer");
			} else {
				System.out.println(i + " is odd integer");
			}
		}

		System.out.println("-------------------------------------------------");

		for (int i = 1; i <= num; i++) {
			String str = (i%2 == 0) ? i + " is even integer" : i + " is odd integer";
			System.out.println(str);
		}
		

	}

}
