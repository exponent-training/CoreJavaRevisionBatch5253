package com.patterns;

import java.util.Scanner;

public class Pattern3 {

	public static void main(String[] args) {

		System.out.println("enter value of n: ");
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		// For rows
		for (int i = 1; i <= n; i++) {

			// for columns
			for (int j = 1; j <= i; j++) {
				System.out.print(i + " ");
			}
			System.out.println();
		}
	}
}
