package com.arraypgms;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class FindingIntersectionArray {

	public static void main(String[] args) {

		String strArray1[] = { "java", "cpp", "html", "angular", "css" };

		String strArray2[] = { "java", "python", "html", "angular", "js", "java" };

		List<String> list = new ArrayList<String>();
		
		Set<String> set = new HashSet<String>();

		// o/p ===> {"java","html","angular"}

		for (int i = 0; i < strArray1.length; i++) {
			for (int j = 0; j < strArray2.length; j++) {
				if (strArray1[i].equals(strArray2[j])) {
					set.add(strArray1[i]);
				}
			}
		}
		
		System.out.println("intersection of 2 array= : "+set);
	}

}
