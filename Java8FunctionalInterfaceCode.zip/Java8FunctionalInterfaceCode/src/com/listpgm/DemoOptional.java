package com.listpgm;

import java.util.Optional;
import java.util.function.Consumer;

public class DemoOptional {

	public static void main(String[] args) {
		/*
		 * Optional op1 = Optional.empty(); System.out.println(op1);
		 */
		
		/*
		 * String s = null;
		 * 
		 * Optional op2 = Optional.of(s); System.out.println(op2);
		 * System.out.println(op2.get());
		 */
		
		String s1 = "java";
		
		Optional<String> obj1=Optional.ofNullable(s1);
		System.out.println(obj1);
		
		if (obj1.isPresent()) {
			System.out.println(obj1.get() +"is programming lang.");
		} else {
			System.out.println(obj1 +"is null.");
		}
		
		obj1.ifPresent((obj)-> System.out.println(obj+"is programming lang."));
	}
}




