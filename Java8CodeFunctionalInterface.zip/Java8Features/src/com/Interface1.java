package com;

@FunctionalInterface
public interface Interface1 {
	
	public void m1(int n, int j);
	
	

}
