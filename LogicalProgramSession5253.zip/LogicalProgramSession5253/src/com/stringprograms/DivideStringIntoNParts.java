package com.stringprograms;

import java.util.ArrayList;
import java.util.List;

public class DivideStringIntoNParts {

	public static void main(String[] args) {

		String str = "javascript";

		List<String> strList = new ArrayList<String>();

		int l = str.length();

		int n = 5;

		int q = l / n;

		if (l % n == 0) {

			for (int i = 0; i < l; i = i + q) {

				String strNew = str.substring(i, i + q);

				strList.add(strNew);
			}

		} else {
			System.out.println("given string is not divided into equal parts.");
		}

		for (String obj : strList) {
			System.out.println(obj);
		}

	}

}
