package com.neumeric;

import java.util.Scanner;

public class CheckPalidromeNumber {
	
	public static void main(String[] args) {

		/*
		 * Scanner sc = new Scanner(System.in); System.out.println("Enter num: ");
		 */

		int num = 131;

		System.out.println("Original number= " + num);
		
		 int updatedNum = num;

		int sum = 0, rem = 0;

		while (updatedNum > 0) {
			rem = updatedNum % 10;
			sum = sum * 10 + rem;
			updatedNum = updatedNum / 10;
		}

		System.out.println("updatedNum number= " + updatedNum);
		System.out.println("Original number= " + num);
		System.out.println("Rev num= " + sum);
		
		if (num == sum) {
			System.out.println("Palidrome number");
		} else {
			System.out.println("not Palidrome number");
		}
		

	}


}
