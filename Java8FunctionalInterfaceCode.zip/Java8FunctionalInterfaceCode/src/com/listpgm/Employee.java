package com.listpgm;

public class Employee {
	
	int eid;
	
	String ename;
	
	String pancardno;

	public int getEid() {
		return eid;
	}

	public void setEid(int eid) {
		this.eid = eid;
	}

	public String getEname() {
		return ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}

	public String getPancardno() {
		return pancardno;
	}

	public void setPancardno(String pancardno) {
		this.pancardno = pancardno;
	}

	@Override
	public String toString() {
		return "Employee [eid=" + eid + ", ename=" + ename + ", pancardno=" + pancardno + "]";
	}

	public Employee(int eid, String ename, String pancardno) {
		super();
		this.eid = eid;
		this.ename = ename;
		this.pancardno = pancardno;
	}
	
	

}
