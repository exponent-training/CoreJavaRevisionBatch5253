package com.arraypgms;

import java.util.Arrays;
import java.util.Iterator;
import java.util.stream.IntStream;

public class FindingIndexUsingarrayElement {

	public static void main(String[] args) {

		char[] chArray = { 'A', 'B', 'E', 'F' };

		char chInput = 'B';
		/*
		 * for (int i = 0; i < chArray.length; i++) { if(chInput==chArray[i]) {
		 * System.out.println("index = "+i); }else { System.out.println("-1"); } }
		 */

		int[] array = { 77, 45, 67, 12 };

		/*
		 * Arrays.asList(chArray).stream().filter(ch->ch=='B').forEach(e->System.out.
		 * println(e.);); Arrays.stream(chArray).filter()
		 */

		IntStream.range(0, array.length).forEach(i -> {
			if (array[i] == 45) {
				System.out.println(i + "--" + array[i]);
			}
		});

		System.out.println("---------------------------------------");
		IntStream.rangeClosed(0, array.length - 1).filter(i -> array[i] == 45)
				.forEach(i -> System.out.println(i + "--" + array[i]));
	}

}
