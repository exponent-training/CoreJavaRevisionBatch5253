package com.controller;

import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.OptionalDouble;
import java.util.stream.Collectors;

import com.entity.Employee;

public class ApplicationController {

	public static void main(String[] args) {
		// Payload.savePayloadForEmployees(); forEach(System.out.println());

		List<Employee> payloadEmployee = Payload.geAllDetailsOfEmployees();

		// How many male & female employees are there?
		Map<String, Long> map = payloadEmployee.stream()
				.collect(Collectors.groupingBy(Employee::getGender, Collectors.counting()));

		// System.out.println(map);

		// Name of all addresses without duplicates.

		List<String> addresses = payloadEmployee.stream().map(emp -> emp.getAddress()).distinct()
				.collect(Collectors.toList());

		// System.out.println(addresses);

		// Avg salary for male & female.

		Map<String, Double> mapSalary = payloadEmployee.stream()
				.collect(Collectors.groupingBy(Employee::getGender, Collectors.averagingDouble(Employee::getSalary)));

		// System.out.println("salary averages: "+mapSalary);

		// get details of highest paid employees.

		Employee highestpaidEmployee = payloadEmployee.stream()
				.collect(Collectors.maxBy(Comparator.comparing(Employee::getSalary))).get();

		// System.out.println(highestpaidEmployee);

		List<Employee> listEmpafter2020 = payloadEmployee.stream().filter(emp -> emp.getYearOfJoining() >= 2020)
				.collect(Collectors.toList());

		// System.out.println(listEmpafter2020);

		// get details of youngest male employee in Admin dept.

		Optional<Employee> employeeYoungest = payloadEmployee.stream().filter(emp -> emp.getDeptname().equals("Admin"))
				.collect(Collectors.minBy(Comparator.comparing(Employee::getAge)));

		/*
		 * System.out.println(employeeYoungest);
		 * 
		 * employeeYoungest.ifPresent(e->System.out.println(e));
		 * System.out.println(employeeYoungest.get());
		 */

		// System.out.println(payloadEmployee.stream().collect(Collectors.minBy(Comparator.comparing(Employee::getYearOfJoining))).get());

		// max salary

		Employee emp = payloadEmployee.stream().collect(Collectors.maxBy(Comparator.comparing(Employee::getSalary)))
				.get();

		/*
		 * System.out.println("Max salary: "+emp.getSalary());
		 * 
		 * Double maxSalry=
		 * payloadEmployee.stream().mapToDouble(Employee::getSalary).max().getAsDouble()
		 * ;
		 * 
		 * System.out.println("maxSalry: "+maxSalry);
		 */

		// second highest salary.

		// System.out.println(payloadEmployee.stream().mapToDouble(Employee::getSalary).boxed().sorted(Comparator.reverseOrder()).skip(1));;

		List<Double> list1 = payloadEmployee.stream().map(Employee::getSalary).sorted(Comparator.reverseOrder())
				.collect(Collectors.toList());

		System.out.println(payloadEmployee.stream().map(Employee::getSalary).distinct().sorted(Comparator.reverseOrder()).skip(1).findFirst().get());
		;

	}

}
