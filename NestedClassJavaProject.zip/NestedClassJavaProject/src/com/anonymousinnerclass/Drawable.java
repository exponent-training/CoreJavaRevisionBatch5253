package com.anonymousinnerclass;

public interface Drawable {
	
	public void draw();
	
	public void get();

}
