package com.arraypgms;

public class EvenOddElementsInArray {
	
	public static void main(String[] args) {
		int[] array = new int[] {101,210,300,453,50,607};
		
		for(int i = 0;i<array.length;i++) {
			if (array[i]%2==0) {
				System.out.println("Even elements: "+array[i]);
			} else {
				System.out.println("Odd elements: "+array[i]);
			}
		}
	}

}
