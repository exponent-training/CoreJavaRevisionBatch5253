package com.patterns;

public class PatternChar3 {
	
	public static void main(String[] args) {

		/*
		 * System.out.println("enter value of n: "); Scanner sc = new
		 * Scanner(System.in); int n = sc.nextInt();
		 */
		// For rows  char a= 97 z = 122   A 65 Z 90
		for (int i = 97; i <= 102; i++) {

			// for columns
			for (int j = 97; j <= i; j++) {
				System.out.print(j+" ");
			}
			System.out.println();
		}
	}

}
