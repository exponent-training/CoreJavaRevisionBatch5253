package com.stringprograms;

import java.util.ArrayList;
import java.util.List;

public class FindingSubsetsOfString {

	public static void main(String[] args) {

		List<String> list = new ArrayList<String>();

		String str = "javascript";

		int l = str.length();

		int n = (l * (l + 1)) / 2;

		for (int i = 0; i < l; i++) {

			for (int j = i; j < l; j++) {

				String s1 = str.substring(i, j + 1);
				list.add(s1);
			}
		}
		
		if (list.size() == n) {
			System.out.println("subset of string: "+list);
			System.out.println("list.size()= "+list.size());
		} else {
			System.out.println("subset not in proper manner!!");
		}
	}

}
