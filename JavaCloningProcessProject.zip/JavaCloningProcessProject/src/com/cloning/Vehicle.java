package com.cloning;

public class Vehicle implements Cloneable {
	
	int vid;
	
	String vehiclename;

	public Vehicle(int vid, String vehiclename) {
		super();
		this.vid = vid;
		this.vehiclename = vehiclename;
	}

	@Override
	public String toString() {
		return "Vehicle [vid=" + vid + ", vehiclename=" + vehiclename + "]";
	}
	
	@Override
	public Object clone() throws CloneNotSupportedException {
		
		Object object1 = super.clone();
		
		return object1;
	}

}



