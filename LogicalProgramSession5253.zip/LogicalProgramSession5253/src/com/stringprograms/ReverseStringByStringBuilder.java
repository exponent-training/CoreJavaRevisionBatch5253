package com.stringprograms;

public class ReverseStringByStringBuilder {

	public static void main(String[] args) {

		String str = "exponent";

		StringBuilder sb = new StringBuilder(str);
		System.out.println("reverse string for " + str + " = " + sb.reverse());

		System.out.println("------------------------------");

		String revstr = "";

		for (int i = str.length() - 1; i >= 0; i--) {
			revstr = revstr + str.charAt(i);
		}
		
		System.out.println("revstr="+revstr);
	}

}
