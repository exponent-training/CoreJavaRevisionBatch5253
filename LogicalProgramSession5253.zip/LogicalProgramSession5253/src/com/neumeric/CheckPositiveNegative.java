package com.neumeric;

import java.util.Scanner;

public class CheckPositiveNegative {
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter num: ");
		int num = sc.nextInt();
		
		if (num>0) {
			System.out.println(num+" is positive integer");
		} else {
			System.out.println(num+" is negative integer");
		}
		
		System.out.println("-------------------------------------------------");
		
		String str = (num>0) ? num+" is positive integer" : num+" is negative integer";
		System.out.println(str);
	}

}
