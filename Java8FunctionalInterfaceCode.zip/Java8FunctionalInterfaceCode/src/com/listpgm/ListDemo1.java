package com.listpgm;

import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;

public class ListDemo1 {
	
	public static void main(String[] args) {
		
		List<Integer> list = Arrays.asList(67,82,11,14,56,73);
		
		System.out.println(list);
		
		Predicate<Integer> p = (n)->(n%2==0);
		
		for (Integer i : list) {
			if (p.test(i)) {
				System.out.println("even no: "+i);
			} else {
				System.out.println("odd no: "+i);
			}
		}
		
		System.out.println("------Consumer------------");
		Consumer<Integer> c = (n)->System.out.println(n+5);
		
		for (Integer j : list) {
			c.accept(j);
		}
		
		System.out.println("------Function------------");
		
		Function<Integer, Integer> f = (n) -> {return (n*n);};
		
		for (Integer i : list) {
			System.out.println(f.apply(i));
		}
		
	}
	
	
	
	
	
	
	
	

}
