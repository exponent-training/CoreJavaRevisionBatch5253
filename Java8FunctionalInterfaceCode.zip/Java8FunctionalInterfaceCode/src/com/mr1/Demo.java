package com.mr1;

public class Demo {
	
	public void display(int i) {
		System.out.println("Welcome to exponent.."+i);
	}

}
