package com.mr;

@FunctionalInterface
public interface Addable {

	public void add();
}
