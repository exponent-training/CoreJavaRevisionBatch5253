package com;

public class Student {
	
	
	@Override
	protected void finalize() throws Throwable {
		System.out.println("finalize method called..");
		System.out.println("Object get destroyed!!");
	}
	
	public static void main(String[] args) {
		Student s3= new Student(); 
		s3=null;
		
		Student s1= new Student();
		Student s2= new Student();
		s1 = s2;
		
		//System.gc();
		
		Runtime.getRuntime().gc();
	}

}
