package com.api;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

public class DemoStreamApiMethods1 {

	public static void main(String[] args) {
		
		List<Integer> list = Arrays.asList(6,3,12,45,78,1,4);
		
		Stream<Integer> iStream = list.stream();
		
		System.out.println("---------even------------");
		
		iStream.filter(n->n%2==0).forEach(System.out::println);
		
		System.out.println("---------Odd------------");
		
		//iStream.filter(n->n%2!=0).forEach(System.out::println);
		
		Arrays.asList(4,5,6,1,33,55,24,4,7,6,1).stream().filter(n->n%2!=0).forEach(System.out::println);
		System.out.println("--------- distinct even------------");
		Arrays.asList(1,2,66,5,2,4,7,66,64,4).stream().filter(n->n%2==0).distinct().forEach(System.out::println);
		
		Long countOfEvenno =Arrays.asList(4,5,6,1,33,55,24,4,7,6,1).stream().filter(n->n%2==0).count();
		
		Arrays.asList(4,5,6,1,33,55,24,4,7,6,1).stream().filter(n->n%2==0);
		
		System.out.println("count= "+countOfEvenno);
		
		System.out.println("------------------");
		Arrays.asList(1,2,3,4,5,6).stream().skip(2).forEach(System.out::println);
		
		System.out.println("------------------");
		Arrays.asList(1,2,3,4,5,6).stream().limit(4).forEach(System.out::println);
		
		
		System.out.println("--------max---------");
		Arrays.asList(1,2,3,4,5,6).stream().skip(5).forEach(System.out::println);
		
		System.out.println("--------max- list--------");
		
		
		Arrays.asList(1,2,3,4,5,6).stream().skip(Arrays.asList(1,2,3,4,5,6).size()-1).forEach(System.out::println);
		
		
		
		
		
		
		
		
}
}
