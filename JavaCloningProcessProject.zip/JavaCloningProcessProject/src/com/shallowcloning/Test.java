package com.shallowcloning;

public class Test {

	
	public static void main(String[] args) {
		
		Address address1 = new Address(411033, "Pune");
		
		Student s1 = new Student(11, "Raj", address1);
		
		System.out.println("Original copy of student:");
		System.out.println(s1);
		System.out.println(s1.hashCode());
		
		System.out.println(s1.address.hashCode());
		
		Student s2 = null;
		
		System.out.println("----------------------");
		System.out.println("---------------cloned student object--------------");
		
		try {
			s2= (Student) s1.clone();
		} catch (CloneNotSupportedException e) {
			System.out.println(e);
		}
		
		System.out.println(s2);
		System.out.println(s2.hashCode());
		System.out.println(s2.address.hashCode());
		
		System.out.println("------------------------------------");
		
		s2.address.city="Mumbai";
		
		System.out.println("s1.address.city: "+s1.address.city);
		
		System.out.println("s2.address.city: "+s2.address.city);
	}
}
