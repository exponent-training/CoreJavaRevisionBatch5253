package com.arraypgms;

public class PrintingArrayElementsEvenOddPosition {

	public static void main(String[] args) {
		
		int[] array = new int[] {100,200,300,400,500,600};
		
		for(int i = 0; i< array.length;i++) {
			if (i%2==0) {
				System.out.println("Even position: "+array[i] );
			} else {
				System.out.println("Odd position: "+array[i] );
			}
		}
	}
}
