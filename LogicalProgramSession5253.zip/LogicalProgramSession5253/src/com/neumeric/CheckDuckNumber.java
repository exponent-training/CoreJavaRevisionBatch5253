package com.neumeric;

import java.util.Scanner;

public class CheckDuckNumber {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter value of n: ");
		int n = sc.nextInt();

		// int n = 5;

		int rem = 0;
		boolean flag = false;

		int temp = n;

		while (temp > 0) {
			rem = temp % 10;
			if (rem == 0) {
				flag = true;
				break;
			}
			temp = temp / 10;
		}

		String str = (flag) ? n + " is Duck number." : n + " is not a Duck number.";

		System.out.println(str);

	}
}
