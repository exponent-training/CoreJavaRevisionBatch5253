package com.deepcloning;

public class Application {

	public static void main(String[] args) {

		Address address1 = new Address(411024, "pune");

		Student s1 = new Student(11, "Raj", address1);

		Student s2 = null;

		System.out.println("-----------------Origibnal copy of student------------");

		System.out.println(s1);
		System.out.println(s1.hashCode());
		System.out.println(s1.address);
		System.out.println(s1.address.hashCode());

		try {
			s2 = (Student) s1.clone();
		} catch (CloneNotSupportedException e) {
			// TODO: handle exception
		}

		System.out.println("-----------------Cloned copy of student------------");

		System.out.println(s2);
		System.out.println(s2.hashCode());
		System.out.println(s2.address);
		System.out.println(s2.address.hashCode());

		System.out.println("------------------------------------");

		s2.address.city = "Mumbai";

		System.out.println("s1.address.city: " + s1.address.city);

		System.out.println("s2.address.city: " + s2.address.city);

	}
}
