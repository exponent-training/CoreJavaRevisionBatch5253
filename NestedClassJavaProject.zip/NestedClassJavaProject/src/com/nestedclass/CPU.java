package com.nestedclass;

public class CPU {

	private int noOfCores = 2;

	int num = 100;

	class ArithmeticLogicUnit {

		int i = 125;
		int j = 5;

		public void calculate() {
			System.out.println("Addition: " + (i + j));
			System.out.println("Substraction: " + (i - j));
			System.out.println("Product: " + (i * j));
			System.out.println("Quotient: " + (i / j));
		}

		public void displayInfo() {
			System.out.println("CPU with noOfCores= " + noOfCores);
		}
	}

	class RAMMemory {
		int memorysize = 16;

		int num = 500;

		boolean isVolite = true;

		public void displayRamData() {
			if (isVolite) {
				System.out.println("Memory size= " + memorysize);
			} else {
				System.out.println("RAM is not volatile...");
			}
		}

		public void usageOfSameVariables() {
			System.out.println("num of RAM: " + this.num);
			System.out.println("num of RAM: " + CPU.this.num);

		}

	}

	private static class Cache {

		public int getcache() {
			return 4;
		}
	}

	public void getInstanceOfCache() {
		Cache c = new Cache();
		int ch = c.getcache();

		System.out.println("ch= " + ch);
	}

	public static void main(String[] args) {
		Cache ch1 = new Cache();
	}
}
