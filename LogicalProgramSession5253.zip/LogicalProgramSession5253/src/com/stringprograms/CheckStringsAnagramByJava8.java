package com.stringprograms;

import java.util.Arrays;
import java.util.stream.Collector;
import java.util.stream.Collectors;

public class CheckStringsAnagramByJava8 {

	public static void main(String[] args) {

		String s1 = "care";
		String s2 = "Race";

		String s1Lower = s1.toLowerCase();
		String s2Lower = s2.toLowerCase();

		char[] chArray1 = s1Lower.toCharArray();
		char[] chArray2 = s2Lower.toCharArray();

		
		if (s1Lower.length() == s2Lower.length()) {

			String str1 = Arrays.stream(s1Lower.split("")).sorted().collect(Collectors.joining(""));
			String str2 = Arrays.stream(s2Lower.split("")).sorted().collect(Collectors.joining(""));

			String anagramStr = str1.equals(str2) ? "given strings are anagram." : "given strings are not anagram.";

			System.out.println(anagramStr);

		
		} else {
			System.out.println("lengths of given strings are not equal , so strings are not Anagram.");
		}

	}
}
