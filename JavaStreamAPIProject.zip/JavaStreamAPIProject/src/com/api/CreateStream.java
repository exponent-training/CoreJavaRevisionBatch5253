package com.api;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.stream.DoubleStream;
import java.util.stream.IntStream;
import java.util.stream.LongStream;
import java.util.stream.Stream;

public class CreateStream {

	public static void main(String[] args) {

		Stream<String> stream1 = Stream.of("abc", "pqr", "xyz");

		String[] array = { "java", "js", "cpp" };

		Stream<String> stream2 = Arrays.stream(array);

		stream2.forEach(System.out::println);

		System.out.println("---------------------");

		List<String> list = Arrays.asList("java", "js", "angular", "cpp");

		Stream<String> stream3 = list.stream();

		stream3.forEach(System.out::println);

		

	}

}
