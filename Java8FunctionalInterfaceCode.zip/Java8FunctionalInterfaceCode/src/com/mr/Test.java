package com.mr;

public class Test {
	
	public static void main(String[] args) {
		
		System.out.println("lambda===");
		Addable a = ()->System.out.println(56+4);
		a.add();
		
		System.out.println("-----------Method reference");
		
		Addable a1 = TotalClass::sum;
		a1.add();
		
		Demo d = new Demo();
		Printable p = d::m2;
		
		p.print();
		Printable p1 = new Demo()::m2;
		
		p1.print();
	}

}
